# CampusEats GraphQL — Dishes Service (MongoDB)
**CS543 · Web Services · Assignment 7 of 12**

This version uses **MongoDB and Mongoose**, not MySQL. It exposes the CampusEats Menu/Dishes service through Apollo GraphQL and a plain HTML/CSS frontend.

## 1. Which CampusEats service did you pick?
We picked the **Menu/Dishes service**. It lists campus dishes and lets a user add a dish.

## 2. Name one field a client can skip and one it cannot. Why use `!`?
A client can skip `available` in a query selection set if it does not need the status. It cannot omit `name` from `AddDishInput`, because `name: String!` is required. GraphQL `!` means non-null: required inputs must be supplied and non-null output fields must not resolve to null.

## 3. Map the GraphQL operation to the database.
For `dish(id: ID!)`, the resolver passes the supplied ID to `Dish.findById(id)`, which looks up the MongoDB document by `_id`. The `addDish` mutation resolver creates and saves a new Mongoose document using `new Dish(...).save()`.

## Team — Group ID 21
| Roll number | Name |
|---|---|
| 20251651097 | Tisha Bagra |
| 20251651045 | Ishu Rajput |
| 20251651051 | Komal |
| 20251651103 | Vinita Rathore |
| 20251651080 | Rupini C Bhojannavar |

## Run the project
Requirements: Node.js 18+ and MongoDB Community Server running locally, or a MongoDB Atlas connection string.

1. Extract the ZIP and open the folder in VS Code.
2. Copy `.env.example` to `.env`. The default URI is `mongodb://127.0.0.1:27017/campuseats_graphql`. For Atlas, replace it with your connection string.
3. Run `npm install`, then `npm start` in the project terminal.
4. Open **http://localhost:4000**. The server connects to MongoDB and inserts four sample dishes on first run if the collection is empty.
5. GraphQL endpoint: **http://localhost:4000/graphql**.

### Example query
```graphql
query { dishes { id name price available } }
```
### Example mutation
```graphql
mutation { addDish(input: { name: "Paneer Roll", price: 90 }) { id name price } }
```

## Submission checklist
- Capture a before screenshot showing the initial four dishes.
- Add `Paneer Roll` at price `90`, then capture the after screenshot.
- Record a short demo video and upload it with both screenshots to Google Drive.
- Push this project to your team's GitHub repository and paste the links below.

GitHub repository: **[Add your team repository URL]**  
Google Drive demo and screenshots: **[Add your share link]**

Note: Run and test locally, verify MongoDB connectivity, capture actual screenshots, record the video, and upload those deliverables.
