const path = require("path");
const fs = require("fs");
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const { ApolloServer } = require("@apollo/server");
const { expressMiddleware } = require("@apollo/server/express4");
const Dish = require("./models/Dish");
require("dotenv").config();
const typeDefs = fs.readFileSync(path.join(__dirname, "schema.graphql"), "utf8");
const resolvers = {
  Query: {
    dishes: async () => Dish.find().sort({ _id: 1 }),
    dish: async (_, { id }) => mongoose.isValidObjectId(id) ? Dish.findById(id) : null
  },
  Mutation: {
    addDish: async (_, { input }) => {
      const dish = new Dish({ name: input.name, price: input.price, available: input.available === undefined ? true : input.available });
      return dish.save();
    }
  },
  Dish: { id: dish => dish._id.toString() }
};
async function start() {
  await mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/campuseats_graphql");
  console.log("Connected to MongoDB");
  if (await Dish.countDocuments() === 0) {
    await Dish.insertMany([
      { name: "Veg Burger", price: 80, available: true },
      { name: "Masala Dosa", price: 70, available: true },
      { name: "Paneer Wrap", price: 110, available: true },
      { name: "Cold Coffee", price: 60, available: false }
    ]);
    console.log("Inserted four sample dishes");
  }
  const app = express(); app.use(cors()); app.use(express.static(path.join(__dirname, "public")));
  const apollo = new ApolloServer({ typeDefs, resolvers }); await apollo.start();
  app.use("/graphql", express.json(), expressMiddleware(apollo));
  const port = Number(process.env.PORT || 4000);
  app.listen(port, () => console.log(`Frontend: http://localhost:${port} | GraphQL: http://localhost:${port}/graphql`));
}
start().catch(err => { console.error("Failed to start service:", err); process.exit(1); });
