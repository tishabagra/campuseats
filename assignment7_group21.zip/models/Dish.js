const mongoose = require("mongoose");
const dishSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  price: { type: Number, required: true, min: 0.01 },
  available: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model("Dish", dishSchema);
